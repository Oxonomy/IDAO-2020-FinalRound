import os
import numpy as np
import pandas as pd
from joblib import dump, load
from sklearn import linear_model, metrics
from sklearn.model_selection import train_test_split

import config as c
from pipeline.model import EnsembleModels, Model

from utils.metrics import roc_auc_score_at_K
from utils.preprocess import reset_averages

class LinearRegression(Model):
    default_model_constructor_parameters = {
        'kernel': 'linear',
        'gamma': 1e-1,
        'tol': 1e-3,
        'C': 1.0
    }

    def __init__(self):
        super().__init__("linear_regression")

    def create_model(self, parameters: dict):
        """
        Созднание модели
        :param parameters: Гиперпараметры модели
        """
        self.model = linear_model.LinearRegression()

    def fit_model(self, x, y, test_size=0.2) -> float:
        """
        Обучение модели
        :return: Обученная модель, Скор
        """
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=c.SEED)
        self.model.fit(x_train, y_train)
        return self.score(x_test, y_test)

    def score(self, x, y):
        y_prediction = self.predict(x)
        return -roc_auc_score_at_K(reset_averages(y_prediction), y, rate=0.1)

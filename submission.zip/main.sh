export PATH=/usr/conda/bin:$PATH
python main_kirill.py
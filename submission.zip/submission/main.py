import numpy as np
import pandas as pd
from joblib import load

def preprocess(df):
    
    cols = [el for el in list(df.select_dtypes(include=['object']).columns) if el != 'card_id']
    #df = pd.get_dummies(df, columns=cols)
    df = df.drop(cols, axis=1)
    '''na_cols = df.loc[:, df.isna().any()].columns
    for col in na_cols:
        df[col + '_na'] = df[col].isna().astype(int)'''

    df = df.fillna(0)
    
    return df


test = pd.read_csv("test.csv")

prediction = test[["card_id"]].copy(deep=True)
model = load('main.joblib')
test = preprocess(test)

prediction["target"] = model.predict(test.drop(['card_id'], axis=1).values) #np.random.rand(test.shape[0])
prediction.to_csv("prediction.csv", index=False)
print('csv created')